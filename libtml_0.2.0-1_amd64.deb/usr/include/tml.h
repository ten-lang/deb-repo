#ifndef ten_load_h
#define ten_load_h

#include <ten.h>

int
tml_install( ten_State* state, char const* ppro, char const* plib, char const* lang );

#endif
